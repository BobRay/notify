<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
Subscribe
--------------------
Author: Bob Ray <http://bobsguides/com>

Official Documentation: http://bobsguides.com/subscribe-tutorial.html
Bugs and Feature Requests: https://github.com/BobRay/Subscribe
Questions: http://forums.modx.com
',
    'changelog' => 'Changelog for Subscribe

Subscribe 1.2.0
---------------
Added option to manage user group membership
Register/Manage prefs form captions converted to lex strings
Code cleanup
Minor bug fixes


Subscribe 1.1.4
---------------
Reversed captions and values in PrefList Tpl chunk
Renamed JS and CSS file and path System Settings
Miscellaneous bug fixes and improvements

Subscribe 1.1.3
---------------
 Refactored to use System Settings
 All System Settings set on install
 Works with no user configuration
 New Users now get role of Subscriber
 Numerous bug fixes

Subscribe 1.1.1
---------------
 Added Manage Preferences feature
 Added Unsubscribe feature
 Renamed chunks for consistency and collision avoidance
 Changed all prefixes to sbs
 Chunks renamed with Sbs prefix and Tpl postfix

Subscribe 1.0.1
---------------
 Changes to CSS
 Better rendering on mobile devices
 No longer uses JQuery
 Minor bugfixes


Subscribe 1.0.0
---------------
Initial Version',
    'setup-options' => 
    array (
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '404b781a4ec5778ce8e51a5cdda16b3d',
      'native_key' => 'subscribe',
      'filename' => 'modNamespace/8baf5f370a40ddf7628825d816582a5e.vehicle',
      'namespace' => 'subscribe',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '2b5a5e8dd6b10588f99191585bfdfcfc',
      'native_key' => 1,
      'filename' => 'modResource/0f349cde6a756281885ddcd8ea6740d2.vehicle',
      'namespace' => 'subscribe',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '895ee75bd990b3c5a46bea23ddca8683',
      'native_key' => 2,
      'filename' => 'modResource/68515f0d5093e5ba1aab1fc31aaf0267.vehicle',
      'namespace' => 'subscribe',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '86aeecb18e956f110c7da5ddcb692ca5',
      'native_key' => 3,
      'filename' => 'modResource/f0471e85531897ee1d4544959ae5c3c7.vehicle',
      'namespace' => 'subscribe',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '9324a5654fd9764f44b5e1369e61fd35',
      'native_key' => 4,
      'filename' => 'modResource/8b292ad3f04b4a97a77c100d4a713f25.vehicle',
      'namespace' => 'subscribe',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '2b93cf3d1c81712058fbe696266d48a5',
      'native_key' => 5,
      'filename' => 'modResource/27116072ed655ce0b8ba6631102784ce.vehicle',
      'namespace' => 'subscribe',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1df3b46f48cd7849a3036275d5a4947e',
      'native_key' => 6,
      'filename' => 'modResource/18ec5446f4ddd1687f11b7bea16927b5.vehicle',
      'namespace' => 'subscribe',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'dbc83590fb9e6f5e1678f6aedfa99ed7',
      'native_key' => 7,
      'filename' => 'modResource/a032c9b9dabff2cba4bb3aaa4b13528b.vehicle',
      'namespace' => 'subscribe',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '324730f4b71e25272bcde22755c613ef',
      'native_key' => 'sbs_register_page_id',
      'filename' => 'modSystemSetting/45193bdc75eb4aa7d10a3196e39fdfba.vehicle',
      'namespace' => 'subscribe',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43e10b241321d5840bd50837689dc374',
      'native_key' => 'sbs_login_page_id',
      'filename' => 'modSystemSetting/56a089474d6d32f3dd521ab0ce727e7d.vehicle',
      'namespace' => 'subscribe',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ccbfce3b98814d11219b768194781b9',
      'native_key' => 'sbs_confirm_register_page_id',
      'filename' => 'modSystemSetting/83ae06a110768fd83e1366499ff94ebf.vehicle',
      'namespace' => 'subscribe',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '123ff901ecb586d1563483d73a1126a2',
      'native_key' => 'sbs_manage_prefs_page_id',
      'filename' => 'modSystemSetting/038c570c0d3f7e864d4c89c2e83c2b8d.vehicle',
      'namespace' => 'subscribe',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6124f129b406b0e9269f604a73367149',
      'native_key' => 'sbs_registration_confirmed_page_id',
      'filename' => 'modSystemSetting/597e856f7ccf0a2e970fb4729321efbf.vehicle',
      'namespace' => 'subscribe',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0ceab0cd3e88ead700436e96fc6a440',
      'native_key' => 'sbs_thank_you_page_id',
      'filename' => 'modSystemSetting/5b1733f9287551005ac4644261f657fa.vehicle',
      'namespace' => 'subscribe',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dedbd2db9a8494529577d090b929ee5',
      'native_key' => 'prefListTpl',
      'filename' => 'modSystemSetting/27613d8e04ffe7c74d61a805542be2ef.vehicle',
      'namespace' => 'subscribe',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5912c5af3097bd64aa58cb79c3e321f2',
      'native_key' => 'groupListTpl',
      'filename' => 'modSystemSetting/f8a8a0408e92aae8abb54f8975b45e77.vehicle',
      'namespace' => 'subscribe',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc1b6e155538601f4d58d9189f2ef990',
      'native_key' => 'checkboxTpl',
      'filename' => 'modSystemSetting/77e390a72663a1e257fca43eadf12ead.vehicle',
      'namespace' => 'subscribe',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fd68f4bb0b9e3619c1805df86dfd8a6',
      'native_key' => 'loggedOutDisplayTpl',
      'filename' => 'modSystemSetting/cf1d51e0bce8fd4281a16b8d7dec62cd.vehicle',
      'namespace' => 'subscribe',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27dee5bf8f5ffb3cc6839dcbd1047a3f',
      'native_key' => 'loggedInDisplayTpl',
      'filename' => 'modSystemSetting/4c2edf7d66b14715251066e5906adf36.vehicle',
      'namespace' => 'subscribe',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee262f7287689e35d5049eeba5aae5dd',
      'native_key' => 'whyDialogTpl',
      'filename' => 'modSystemSetting/0551c2bace95a6b83f5867962372d71a.vehicle',
      'namespace' => 'subscribe',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c764abe0d254811f443b2e40cb2d9c5d',
      'native_key' => 'whyDialogTextTpl',
      'filename' => 'modSystemSetting/1c7e5f4065085bd97ac5003bf32e5222.vehicle',
      'namespace' => 'subscribe',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '534d2de4da21f88059efda5954134cb0',
      'native_key' => 'privacyDialogTpl',
      'filename' => 'modSystemSetting/5ad800c01f8d656ed11ddf8f005ee0d8.vehicle',
      'namespace' => 'subscribe',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccccc28f14f7f314df41992d53401569',
      'native_key' => 'privacyDialogTextTpl',
      'filename' => 'modSystemSetting/9011acb2378f9e3656d76efc33825a2d.vehicle',
      'namespace' => 'subscribe',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7af57c48b6aa1e90b4caad590a9128d3',
      'native_key' => 'sbsCssPath',
      'filename' => 'modSystemSetting/55c3c1bf1cc153ace168fbfa6b703b8f.vehicle',
      'namespace' => 'subscribe',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e8f7ecf968706553e0e044aaf685e70',
      'native_key' => 'sbsCssFile',
      'filename' => 'modSystemSetting/6256e1b1a0a48993a60e678e6bc552ad.vehicle',
      'namespace' => 'subscribe',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bda9447fa8151733797f992d7fbb8a3',
      'native_key' => 'sbsJsPath',
      'filename' => 'modSystemSetting/5ac18901b00380838aa82476ff7f55c4.vehicle',
      'namespace' => 'subscribe',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a01364bd68be8be0510caf75f799c8de',
      'native_key' => 'sbsJsFile',
      'filename' => 'modSystemSetting/455abcce055aa59eb70d88dc3ed1f337.vehicle',
      'namespace' => 'subscribe',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf7fbfa1c4fb117d9f2db49d7ed9b1e7',
      'native_key' => 'sbs_use_comment_field',
      'filename' => 'modSystemSetting/6b1b16a0d9e022900ba42274e56447ef.vehicle',
      'namespace' => 'subscribe',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1e15d71f25006006cbc693a7a5caeaa',
      'native_key' => 'sbs_extended_field',
      'filename' => 'modSystemSetting/3d4e9e07b452d358c56a60c971907106.vehicle',
      'namespace' => 'subscribe',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b4cd9926996bfe08bec9a9f5fe2a6fc',
      'native_key' => 'language',
      'filename' => 'modSystemSetting/f2d16327ab843ec7e087baea7a3b631d.vehicle',
      'namespace' => 'subscribe',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cca6c66e4f108bb86aae3ddb24a5a0c3',
      'native_key' => 'sbs_secret_key',
      'filename' => 'modSystemSetting/8cd6f8b0e8bf013ab2cf567383a4666c.vehicle',
      'namespace' => 'subscribe',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6b0af23f87722639feae91ccbedfc6e',
      'native_key' => 'sbs_unsubscribe_page_id',
      'filename' => 'modSystemSetting/f23bb17eba7649a55c09761323927754.vehicle',
      'namespace' => 'subscribe',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef9961bfba459f4b959451458bb1224f',
      'native_key' => 'sbs_user_roles',
      'filename' => 'modSystemSetting/2cfbaf8f721cb827c2d0ed94031f12ba.vehicle',
      'namespace' => 'subscribe',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01d66a7198d36ec2c80546e307267836',
      'native_key' => 'sbs_show_interests',
      'filename' => 'modSystemSetting/8df57923e903384ccfaabce8406a45fd.vehicle',
      'namespace' => 'subscribe',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00e4e84a34978d2a5f75b851f736bd21',
      'native_key' => 'sbs_show_groups',
      'filename' => 'modSystemSetting/68b1c24544a79abbb7600451f71c7e0c.vehicle',
      'namespace' => 'subscribe',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6d6d45b237391496940eace90f29f77',
      'native_key' => 'sbs_field_name',
      'filename' => 'modSystemSetting/3103a6bb4870a0b03430af1258995f0f.vehicle',
      'namespace' => 'subscribe',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55325228bda7dfdfcc9fedb6a365327d',
      'native_key' => 'sbs_groups_field_name',
      'filename' => 'modSystemSetting/f515b3877451ddc7d182124d18582543.vehicle',
      'namespace' => 'subscribe',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '04e81ac362faccfd6c028ee2d8ce27d4',
      'native_key' => 1,
      'filename' => 'modCategory/4ca55c2221f9c0c055d5450d8a8daee7.vehicle',
      'namespace' => 'subscribe',
    ),
  ),
);