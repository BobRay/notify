--------------------
Subscribe
--------------------
Author: Bob Ray <http://bobsguides/com>

Official Documentation: http://bobsguides.com/subscribe-tutorial.html
Bugs and Feature Requests: https://github.com/BobRay/Subscribe
Questions: http://forums.modx.com
