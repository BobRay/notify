<?php


/** @var $modx modX */
/** @var  $scriptProperties array */

if (!defined('MODX_CORE_PATH')) {
    require_once 'c:/xampp/htdocs/addons/assets/mycomponents/instantiatemodx/instantiatemodx.php';
}

$corePath = $modx->getOption('mandrillx.core.path', NULL, $modx->getOption('core_path') . 'components/mandrillx/');

if (!isset($scriptProperties)) {
    $scriptProperties = array(
        // 'html'       => $tpl,
        'subaccount' => 'test',
        'subject'    => 'New Update',
        'includeTVs' => '1',
        'includeTVList' => 'rt3',
    );
}



$apiKey = $modx->getOption('mandrill_api_key', null, '');


require_once $corePath .  'model/mandrillx/mandrillx.class.php';

$docId = 38;
$doc = $modx->getObject('modResource', $docId);
if (! $doc) {
    die ('No Document');
}

$fields = $doc->toArray();

$includeTVs = $modx->getOption('includeTVs', $scriptProperties, false);
$includeTVList = !empty($includeTVList) ? explode(',', $includeTVList) : array();

if ($includeTVs) {
    if (!empty($includeTVList)) {
        $tvs = $modx->getCollection('modTemplateVar', array('name:IN' => $includeTVList));
    } else {
        $tvs = $doc->getMany('TemplateVars');
    }

    foreach($tvs as $tvId => $templateVar) {
        /** @var $templateVar modTemplateVar */
        $fields[$templateVar->get('name')] = $templateVar->renderOutput($docId);
    }
}

$tpl = $modx->getChunk('MandrillExampleTpl', $fields);
if (empty($tpl)) {
    die('No Tpl');
}

$scriptProperties['html'] = $tpl;

unset($tvs, $tpl, $tvId, $tvName, $fields, $doc);

$mx = new MandrillX($modx, $apiKey, $scriptProperties);
$mx->init();

$globalMergeVars = array(

);

$mx->setGlobalMergeVars($globalMergeVars);

$user = array(
    'email' => 'bobray@softville.com',
    'name' => 'Bob Ray',
    'firstname' => 'Bob',
    'lastname' => 'Ray',
    'UNSUBSCRIBEURL' => 'http://bobsguides.com/unsubscribe.html',
    'username' => 'BobRay',
);

$mx->addUser($user);

$user = array(
    'email'          => 'bobray99@gmail.com',
    'name'           => 'Joe Blow',
    'firstname'      => 'Joe',
    'lastname'       => 'Blow',
    'UNSUBSCRIBEURL' => 'http://bobsguides.com/Joesunsubscribe.html',
    'username'       => 'JoeBlow',
);

$mx->addUser($user);

$results = $mx->sendMessage();

$output = '';
// print_r($results);
foreach($results as $result) {
    if ($result['status'] == 'sent') {
        $output .= "\n" . $result['email'] . ' - Success';
    } else {
        $msg = empty($result['reject_reason'])? $result['status'] : $result['reject_reason'];
        $output  .= "\n" . $result['email'] . ' Rejected: ' . $msg;
    }
}

if (php_sapi_name() == 'cli') {
    echo $output;
} else {
    return nl2br($output);
}


