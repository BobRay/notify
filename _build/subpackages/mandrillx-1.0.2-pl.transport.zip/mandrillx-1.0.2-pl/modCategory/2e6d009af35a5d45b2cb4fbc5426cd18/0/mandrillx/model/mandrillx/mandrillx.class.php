<?php
/**
 * MandrillX class file for MandrillX extra
 *
 * Copyright 2013 by Bob Ray <http://bobsguides.com>
 * Created on 02-04-2014
 *
 * MandrillX is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * MandrillX is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * MandrillX; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package mandrillx
 */

require_once dirname(dirname(__FILE__)) . '/mandrill/src/Mandrill.php';

class MandrillX extends Mandrill{
    /** @var $modx modX */
    public $modx;
    /** @var $config array */
    public $config;
    /** @var $message array - master array to sent to Mandrill */
    protected $message;

    protected $subaccount;
    protected $headers;
    protected $important;
    protected $track_opens;
    protected $track_clicks;    
    protected $auto_html;
    protected $auto_text;
    protected $inline_css;
    protected $url_strip_qs;
    protected $preserve_recipients;
    protected $view_content_link;
    protected $bcc_address;
    protected $tracking_domain;
    protected $signing_domain;
    protected $return_path_domain;
    protected $merge;
    protected $subject;
    protected $from_email;
    protected $errors;
    protected $to;
    protected $global_merge_vars;
    protected $merge_vars;
    protected $userPlaceholders;




    function __construct(&$modx, $apiKey, &$config = array()) {
        $this->modx =& $modx;
        $this->config =& $config;
        parent::__construct($apiKey);
    }
    public function init() {
        $config = $this->config;
        $this->message = array();
        $this->errors = array();
        $this->to = array();
        $this->global_merge_vars = array();
        $this->merge_vars = array();

        $this->message['merge'] = true;
        $subject = $this->modx->getOption('subject', $config, '');
        $this->message['subject'] =  !empty($subject)? $subject : 'Update from ' . $this->modx->getOption('site_name');
        $from = $this->modx->getOption('from_email', $config,'');
        $this->message['from_email'] = !empty($from)? $from: $this->modx->getOption('emailsender');

        $from_name = $this->modx->getOption('from_name', $config, '');
        $this->message['from_name'] = !empty($from_name)
            ? $from_name
            : $this->modx->getOption('site_name');

        $html = $this->modx->getOption('html', $config, '');
        if (empty($html)) {
            $this->setError('No Message Content');
            return;
        } else {
            $this->setUserPlaceholders($html);
            // $cProps = $this->modx->getOption('tplProperties', $config, array());
            $this->message['html'] = $this->prepareTpl($html);
        }
        $this->message['important'] = (bool) $this->modx->getOption('important', $config, false);;
        /* subaccount must exist at mandrillapp.com or the send will fail */
        $this->message['subaccount'] = $this->modx->getOption('subaccount', $config, 'test');
        $headers = $this->modx->getOption('headers', $config, '');
        $this->message['headers'] = $this->getHeaders($headers);
        $text = $this->modx->getOption('text', $config, '');
        if (!empty($text)) {
            $this->message['text'] = $text;
        }

        /* All these can be set at mandrillapp.com and omitted from the properties */
        $this->message['track_opens'] = $this->modx->getOption('track_opens', $config, null);
        $this->message['track_clicks'] = $this->modx->getOption('track_clicks', $config, NULL);
        $this->message['auto_html'] = $this->modx->getOption('auto_html', $config, NULL);
        $this->message['auto_text'] = $this->modx->getOption('auto_text', $config, NULL);
        $this->message['inline_css'] = $this->modx->getOption('inline_css', $config, NULL);
        $this->message['url_strip_qs'] = $this->modx->getOption('url_strip_qs', $config, NULL);
        $this->message['preserve_recipients'] = $this->modx->getOption('preserve_recipients', $config, NULL);
        $this->message['view_content_link'] = $this->modx->getOption('view_content_link', $config, NULL);
        $this->message['bcc_address'] = $this->modx->getOption('bcc_address', $config, NULL);
        $this->message['tracking_domain'] = $this->modx->getOption('tracking_domain', $config, NULL);
        $this->message['signing_domain'] = $this->modx->getOption('signing_domain', $config, NULL);
        $this->message['return_path_domain'] = $this->modx->getOption('return_path_domain', $config, NULL);

    }

    /**
     * Process Mandrill-style tags in HTML message text.
     * Snippets and chunk tags will be processed and
     * placeholders will processed if $props is sent.
     * No MODX-style tags allowed.
     *
     * Mandrill-style placeholders must be in all uppercase:
     *    *|PLACEHOLDER|*
     *
     * All other tags must be mixed case in this form:
     *    *|tagContent|*
     *
     * @param $text string - Text of message with Mandrill-style tags.
     * @return string
     */
    public function prepareTpl($text) {
        /*$chunk = $modx->getObject('modChunk', array('name' => $tpl));
        $text = $chunk->getContent();*/
        $text = str_replace('{{+', '*|', $text);
        $text = str_replace('}}', '|*', $text);
        return $text;
    }

    public function setHTML($html) {
        $this->message['html'] = $this->prepareTpl($html);
    }

    public function setText($text) {
        $this->message['text'] = $this->prepareTpl($text);
    }

    /**
     * return an array of extra headers based on $headers property:
     * 'Reply-to:you@yourdomain.com,header2:somevalue';
     * @param $headers
     *
     * if $headers is empty, returns 'Reply-To => emailsender system setting'
     *
     * @return array
     */
    protected function getHeaders($headers) {
        $h = array();
        if (empty($headers)) {
            $h = array(
              'Reply-To' => $this->modx->getOption('emailsender'),
            );
        } else {
            $pairs = explode(',', $headers);
            foreach($pairs as $pair) {
                $couple = explode(':', $pair);
                if (! isset($couple[1])) {
                    return array(); /* error - no headers */
                } else {
                    $h[trim($couple[0])] = trim($couple[1]);
                }

            }
        }
        return $h;
    }

    protected function setError($msg) {
        $this->errors[] = $msg;
    }

    public function getErrors() {
        return $this->errors;
    }
    public function hasError() {
        return !empty($this->errors);
    }
    
    /** 
     * Clears user and merge arrays for batch sending.
     * Options and global merge variables are preserved. 
     */
    public function clearUsers() {
        $this->to = array();
        $this->merge_vars = array();
    }

    public function sendMessage() {
        $this->message['to'] = $this->to;
        $this->message['merge_vars'] = $this->merge_vars;
        $this->message['global_merge_vars'] = $this->global_merge_vars;
        return $this->messages->send($this->message);
    }

    /**
     * @param $fields array - array of key/value pairs for global
     * merge variables (these are the same for every email)
     */
    public function setGlobalMergeVars ($fields) {
        foreach($fields as $key => $value) {
            $key = strtoupper($key);
            $this->global_merge_vars[] = array(
                'name' => $key,
                'content' => $value,
            );
        }
        
    }

    /**
     * Add a user to the $to and $mergeVars array
     * 'email' and 'name' are the only required fields.
     *
     * Placeholders in the message itself should not
     * use those keys.
     *
     * @param $fields
     */
    public function addUser($fields) {
        $vars = array();
        $this->to[] = array(
            'email' => $fields['email'],
            'name' => $fields['name'],
            'type' => 'to',
        );
        foreach($fields as $key => $value) {
            if ($key == 'name' || $key == 'email') {
                continue;
            }
            $vars[] = array(
                'name' => strtoupper($key),
                'content' => $value,
            );
        }
        $this->merge_vars[] = array(
            'rcpt' => $fields['email'],
            'vars' => $vars,

        );
    }

    /**
     *  Sets the array of user placeholder names used in the tpl chunk
     *
     * @param $tpl
     */
    public function setUserPlaceholders($tpl) {
        $pattern = '#\{\{\+([a-zA-Z_\-]+?)\}\}#';
        preg_match_all($pattern, $tpl, $matches);

        $this->userPlaceholders =  isset($matches[1])
            ? $matches[1]
            : array();

    }

    /**
     * Sets the array of user placeholder names used in the tpl chunk
     *
     * @return array
     */
    public function getUserPlaceholders() {
        return $this->userPlaceholders;
    }


}