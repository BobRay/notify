
MandrillX


Author: Bob Ray <http://bobsguides.com>
Copyright 2013-2014

Official Documentation: http://bobsguides.com/mandrillx-class.html

Bugs and Feature Requests: https://github.com:BobRay/MandrillX

Questions: http://forums.modx.com

Created by MyComponent
